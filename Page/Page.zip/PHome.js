import "bootstrap/dist/css/bootstrap.min.css"
import React from "react";

export default function PHome() {
    return (
        <div>
            <div className='HomeonPage'>
                <div className="container-fluid">
                    <div className="border rounded-4 bg-light position-absolute top-50 start-50 translate-middle w-75  p-3 shadow p-3 mb-5 bg-body rounded" >
                        <center><h1>Welcome to Numerical Calculate Website !</h1></center>
                    </div>
                </div>
            </div>
        </div>
    );
};
